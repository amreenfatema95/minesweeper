package minesweeper;

public class TestMinesweeper 
{
	public static void main(String args[])
	{
		//Instantiating the MinesweeperGUI Class.
		MinesweeperGUI test1 = new MinesweeperGUI();
		test1.setVisible(true);
	}
	
	
}
